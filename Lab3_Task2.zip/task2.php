<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <link rel="stylesheet" href="./extras/nouislider.css">
    <script src="./extras/wNumb.js"></script>
    <script src="./extras/nouislider.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
    <style TYPE="text/css">
        body{
            margin: 0 1%;
            background-color: white;

        }
        h2{
            color:#f50057;
            text-align: center;
            margin-top: 5%;
        }
        h4{
            color:#ffff8d;
        }
        #converted{
            margin-top:50px;
            display:flex;
            align-items:center;
            flex-direction: column;
            justify-content: center;
        }
        #converted button{
            margin-left: 5px;
            margin-right: 5px;

        }
        #converted form{
            width:30%;
            
        }
        .row{
            display:flex;
            flex-direction:row;
            justify-content:space-evenly;
            margin:10px auto;
            align-items:center;
            flex-grow: 1;
        }
        .main{
            display:flex;
            flex-direction:row;
            flex-wrap:wrap;
            margin:0 2%:
        }
        .image{
        width:23.8%;
        margin:0.5%;
        }
        .form{
            display:flex;
            flex-direction:column;
            justify-content:center;
            align-items:center;
            width:60%!important;
        }
        .image img{
        width:100%;
        height:100%;
        opacity:1;
        transition:0.2s all ease;
        }
        .image:hover img{
        /* width:100%;
        height:100%; */
        opacity:0.7
        }
        .test-slider{
            width:300px;
        }
   </style>
</head>
<body>



<h2>Flicker API</h2>
<div id="converted">
<form class ="form" action="api.php" method="post" id="myForm">
      
    <div class="row">
         <div class="input-field col s12">
                <p>Longitude bottom</p>
                <div id="longitude_bottom" class="test-slider"></div>
                    <input type='hidden'  id= 'coordinate1' name='coordinate1' value='' />
            </div>
    </div>
    <div class="row">
         <div class="input-field col s12">
                <p>Latitude bottom</p>
                <div id="latitude_bottom"  class="test-slider"></div>
                    <input type='hidden' id='coordinate2' name='coordinate2' value='' />
            </div>
    </div>
    <div class="row">
         <div class="input-field col s12">
                <p>Longitude top</p>
                <div id="longitude_top"  class="test-slider"></div>
                    <input type='hidden' id= 'coordinate3' name='coordinate3' value='' />
            </div>
    </div>
    <div class="row">
         <div class="input-field col s12">
                <p>Latitude top</p>
                <div id="latitude_top"  class="test-slider"></div>
                    <input type='hidden' id= 'coordinate4' name='coordinate4' value='' />
            </div>
    </div>
        <!-- <div class="row">
        <div class="input-field col s12">
        <label for="Latitude">Latitude bottom</label>
          <input id="Latitude" type="text" class="validate" name="coordinate2" teal>
        </div>
        <div class="input-field col s12">
        <label for="Longitude">Longitude top</label>
          <input id="Longitude" type="text" class="validate" name="coordinate3" teal>
        </div>
        <div class="input-field col s12">
        <label for="Latitude">Latitude top</label>
          <input id="Latitude" type="text" class="validate" name="coordinate4" teal>
        </div>
      </div> -->
      <div class="row switch">
            <label>
            Table
            <input type="checkbox" name="json_enable">
            <span class="lever"></span>
            JSON
            </label>
        </div>
      <div class="row">
        <button class="btn teal" onclick="mySubmit()">submit</button>
      </div>
    </form>
    </div>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('select');
    var instances = M.FormSelect.init(elems);
  });

  var slider1 = document.getElementById('longitude_bottom');
  noUiSlider.create(slider1, {
   start: [0],
   connect: true,
   step: 1,
   orientation: 'horizontal', // 'horizontal' or 'vertical'
   range: {
     'min': -180,
     'max': 180
   },
   format: wNumb({
     decimals: 1
   })
  });

  var slider2 = document.getElementById('latitude_bottom');
  noUiSlider.create(slider2, {
   start: [0],
   connect: true,
   step: 1,
   orientation: 'horizontal', // 'horizontal' or 'vertical'
   range: {
     'min': -90,
     'max': 90
   },
   format: wNumb({
     decimals: 1
   })
  });
  
  var slider3 = document.getElementById('longitude_top');
  noUiSlider.create(slider3, {
   start: [0],
   connect: true,
   step: 1,
   orientation: 'horizontal', // 'horizontal' or 'vertical'
   range: {
     'min': -180,
     'max': 180
   },
   format: wNumb({
     decimals: 1
   })
  });
  var slider4 = document.getElementById('latitude_top');
  noUiSlider.create(slider4, {
   start: [0],
   connect: true,
   step: 1,
   orientation: 'horizontal', // 'horizontal' or 'vertical'
   range: {
     'min': -90,
     'max': 90
   },
   format: wNumb({
     decimals: 1
   })
  });

  $("button").click(function(event){
        event.preventDefault();
  });

  function mySubmit() {
     document.getElementById('coordinate1').value = slider1.noUiSlider.get();
     document.getElementById('coordinate2').value = slider2.noUiSlider.get();
     document.getElementById('coordinate3').value = slider3.noUiSlider.get();
     document.getElementById('coordinate4').value = slider4.noUiSlider.get();   
     
     let slide1 = parseInt(slider1.noUiSlider.get());
     let slide2 =parseInt(slider2.noUiSlider.get());
     let slide3 =parseInt(slider3.noUiSlider.get());
     let slide4 =parseInt(slider4.noUiSlider.get());

     console.log(slide1,slide2,slide3,slide4);
     
     if((slide1 < slide3 && slide2<slide4)) {
       
        document.getElementById("myForm").submit();
     }
     else{
       
        M.toast({html: 'The bottom and left values should be smaller than top right values. Try again'});
     }
    //  document.getElementById("myForm").submit();
    }
</script>

</body>
</html>
