<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
    <style TYPE="text/css">
        body{
            margin: 0 1%;
            background-color: white;

        }
        h2{
            color:#f50057;
            text-align: center;
            margin-top: 5%;
        }
        h4{
            color:#ffff8d;
        }
        #converted{
            margin-top:50px;
            display:flex;
            flex-direction: column;
            justify-content: center;
        }
        #converted button{
            margin-left: 5px;
            margin-right: 5px;

        }
        #converted form{
            width:30%;
            
        }
        .row{
            display:flex;
            flex-direction:row;
            justify-content:space-evenly;
            margin:0 auto;
            align-items:center;
            flex-grow: 1;
        }
        .main{
            display:flex;
            flex-direction:row;
            flex-wrap:wrap;
            margin:0 2%:
        }
        .image{
        width:23.8%;
        margin:0.5%;
        }
      
        .image img{
        width:100%;
        height:100%;
        opacity:1;
        transition:0.2s all ease;
        }
        .image:hover img{
        /* width:100%;
        height:100%; */
        opacity:0.7
        }
   </style>
</head>
<body>

<?php
$coordinate1 = $_POST['coordinate1'];
$coordinate2 = $_POST['coordinate2'];
$coordinate3 = $_POST['coordinate3'];
$coordinate4 = $_POST['coordinate4'];

$json_enable = $_POST['json_enable'];


$coordinates = $coordinate1.','.$coordinate2.','.$coordinate3.','.$coordinate4;
// echo "$json_enable";

$params = array(
    'api_key' => '608438ddaaf1f076bfcfa143d4e2a146',
    'method' => 'flickr.photos.search',
    'bbox' => $coordinates,
    'extras' => 'geo',
    'has_geo' => '1',
    'per_page' => '20',
    'page' => '1',
    'format' => 'json',
    'nojsoncallback' => '1',
    );
    $encoded_params = array();
    foreach ($params as $k => $v){


        $encoded_params[] = urlencode($k).'='.urlencode($v);

    }
    $url = "https://api.flickr.com/services/rest/?".implode('&', $encoded_params);
    $rsp = file_get_contents($url);
    $rsp = str_replace( 'jsonFlickrApi(', '', $rsp );
    $rsp = substr( $rsp, 0, strlen( $rsp ) );
    $rsp2 = json_decode($rsp, true);
    // echo '<pre>';
    // var_dump($rsp2);
    // echo '</pre>';
    // Now we display the photos
    $photos = $rsp2['photos']['photo'];
    $imgsrc = 'https://farm'.$photos[0]["farm"].'.staticflickr.com/'.
    $photos[0]["server"] . '/'.$photos[0]["id"].'_'.$photos[0]["secret"].'.jpg';
    // echo '<img src="'.$imgsrc.'">';
    // foreach($photos as $photo){
    //     $imgsrc = 'https://farm'.$photo["farm"].'.staticflickr.com/'.
    //     $photo["server"] . '/'.$photo["id"].'_'.$photo["secret"].'.jpg';
        // echo '<img src="'.$imgsrc.'">';
    // }
//
// // $jsonString = file_get_contents("./GeoData/CalgarySchools.geojson");
//
// echo "<h4>This is the decoded JSON array: </h4>";
// // var_dump(json_decode($jsonString,true));
//
// echo "<br><br>";
//
// echo "<h4>This is the encoded JSON array: </h4>";
// var_dump(json_encode(json_decode($jsonString,true)));

?>
<h2>Flicker API</h2>
<div id="converted">
<!-- <form action='response.php' method="post"> -->
      
      <div class="main">
      <?php
        if($json_enable=='on'){
            echo '<pre>';
            var_dump($rsp2);
            echo '</pre>';
        }
        else{
            foreach($photos as $photo){
                $imgsrc = 'https://farm'.$photo["farm"].'.staticflickr.com/'.
                $photo["server"] . '/'.$photo["id"].'_'.$photo["secret"].'.jpg';
                echo '<div class="image"><img src="'.$imgsrc.'"></div>';
            }
        }
      ?>
      </div>
     
    </div>
     
    <!-- </form> -->
    <!-- <button class="waves-effect  btn" onclick="encode()">Request Encoded Data</button>
    <button class="waves-effect  btn pink lighten-1" onclick="decode()">Request Decoded Data</button> -->
</div>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('select');
    var instances = M.FormSelect.init(elems);
  });
    // function encode(){
    //     var xhttp = new XMLHttpRequest();
    //     xhttp.onreadystatechange = function() {
    //         if (this.readyState == 4 && this.status == 200) {
    //             document.getElementById("converted").innerHTML = this.responseText;
    //         }
    //     };
    //     xhttp.open("GET", "encode.php", true);
    //     xhttp.send();
    // }
    // function decode(){
    //     var xhttp = new XMLHttpRequest();
    //     xhttp.onreadystatechange = function() {
    //         if (this.readyState == 4 && this.status == 200) {
    //             document.getElementById("converted").innerHTML = this.responseText;
    //         }
    //     };
    //     xhttp.open("GET", "decode.php", true);
    //     xhttp.send();
    // }
</script>

</body>
</html>
