<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    
    <style TYPE="text/css">
        body{
            margin: 0 1%;
            background-color: white;
            color:white;

        }
        h2{
            color:#f50057;
            text-align: center;
            margin-top: 5%;
        }
        h4{
            color:#ffff8d;
        }
        #converted{
            margin-top:50px;
            display:flex;
            flex-direction: row;
            justify-content: center;
        }
        #converted button{
            margin-left: 5px;
            margin-right: 5px;

        }
        #converted form{
            width:30%;
            
        }
        .row{
            display:flex;
            flex-direction:row;
            justify-content:space-evenly;
            margin:0 auto;
            align-items:center;
            flex-grow: 1;
        }
     
   </style>
</head>
<body>

<?php

//
// // $jsonString = file_get_contents("./GeoData/CalgarySchools.geojson");
//
// echo "<h4>This is the decoded JSON array: </h4>";
// // var_dump(json_decode($jsonString,true));
//
// echo "<br><br>";
//
// echo "<h4>This is the encoded JSON array: </h4>";
// var_dump(json_encode(json_decode($jsonString,true)));

?>
<h2>School Locator</h2>
<div id="converted">
<form action='response.php' method="post">
      
      <div class="row">
        <div class="input-field col s12">
          <input id="name" type="text" class="validate" name="textfield" teal>
          <label for="name">School Name</label>
        </div>
      </div>
      <div class="row">
      <div class="input-field col s12">
        <select name="dropdown">
            <option value="json">JSON</option>
            <option value="xml">XML</option>
            <option value="csv">CSV</option>
            <option value="table">Table</option>
        </select>
      </div>
      </div>
      <div class="row">
        <p>
            <label>
                <input class="with-gap" name="group1" type="radio" checked value="SE"/>
                <span>SE</span>
            </label>
        </p>
        <p>
            <label>
                <input class="with-gap" name="group1" type="radio" value="SW"/>
                <span>SW</span>
            </label>
        </p>
        <p>
            <label>
                <input class="with-gap" name="group1" type="radio"  value="NE"/>
                <span>NE</span>
            </label>
        </p>
        <p>
            <label>
                <input class="with-gap" name="group1" type="radio"  value="NW"/>
                <span>NW</span>
            </label>
        </p>
        <button class="btn waves-effect waves-light" type="submit" name="action">Submit
        <i class="material-icons right">send</i>
    </button>
     </div>
     
    </div>
     
    </form>
    <!-- <button class="waves-effect  btn" onclick="encode()">Request Encoded Data</button>
    <button class="waves-effect  btn pink lighten-1" onclick="decode()">Request Decoded Data</button> -->
</div>
<script>
  document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('select');
    var instances = M.FormSelect.init(elems);
  });
    // function encode(){
    //     var xhttp = new XMLHttpRequest();
    //     xhttp.onreadystatechange = function() {
    //         if (this.readyState == 4 && this.status == 200) {
    //             document.getElementById("converted").innerHTML = this.responseText;
    //         }
    //     };
    //     xhttp.open("GET", "encode.php", true);
    //     xhttp.send();
    // }
    // function decode(){
    //     var xhttp = new XMLHttpRequest();
    //     xhttp.onreadystatechange = function() {
    //         if (this.readyState == 4 && this.status == 200) {
    //             document.getElementById("converted").innerHTML = this.responseText;
    //         }
    //     };
    //     xhttp.open("GET", "decode.php", true);
    //     xhttp.send();
    // }
</script>

</body>
</html>
