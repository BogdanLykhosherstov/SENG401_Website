<!DOCTYPE html>
<html>
<head>
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
    <style TYPE="text/css">
        body{
            margin: 0 1%;
            background-color: white;

        }
        h2{
            color:#f50057;
            text-align: center;
            margin:0 auto;
        }
        h4{
            color:#ffff8d;
        }
        #converted{
            margin-top:50px;
            display:flex;
            flex-direction: row;
            justify-content: center;
        }
        #converted button{
            margin-left: 5px;
            margin-right: 5px;

        }
        #converted form{
            width:30%;
            
        }
        .row{
            margin-top:4%;
            display:flex;
            align-items:center;
            flex-direction:row;
            justify-content:space-evenly;
            flex-grow: 1;
        }
   </style>
</head>
<body>

<?php

$host='localhost';
$db = 'BigB'; //use pgadmin to create a database e.g. SENG401
$username = 'BigB'; //usually postgres
$password = ''; //usually postgres
$port = 5432;
$dsn = "pgsql:host=$host; port=$port; dbname=$db; user=$username;
password=$password";

try{
    // create a PostgreSQL database connection
    $conn = new PDO($dsn);
    // display a message if connected to the PostgreSQL successfully
    if($conn){
    // echo "Connected to the <strong>$db</strong> database
    // successfully!";
    }
    }catch (PDOException $e){
    // report error message
    echo $e->getMessage();
    }





$name = $_POST['textfield'];
$region =$_POST['group1'];
$format = $_POST['dropdown'];


// echo "<p>$selected_data</p>";
// echo "<p>$test</p>";

// Retrieving query
$queryStatement = "SELECT * FROM calgaryschools WHERE name LIKE '%$name%' AND sector='$region'";
$query = $conn->query($queryStatement);
$results = $query->fetchAll();
// foreach($results as $result)
// {
// echo $result['name'] . ", " . $result['address'] . ", " . $result['postalcode']
// . "<br>";
// }


?>
<div class="row">
    <h2>School Locator</h2> 
    <a class="btn-floating btn-large waves-effect waves-light teal" href="index.php">
        <i class="material-icons">
            keyboard_arrow_left
        </i>
    </a>
</div>
<div id="converted">
<?php
if ($format=="table"){
?>
 <div class="row"> 
        <table class="highlight responsive-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Type</th>
                    <th>Sector</th>
                    <th>Address</th>
                    <th>City</th>
                    <th>Province</th>
                    <th>Postal Code</th>
                    <th>Longitude</th>
                    <th>Latitude</th>
                 </tr>
            </thead>
            <tbody>
                    <?php
                        foreach($results as $result){
                            echo "<tr>";

                            echo "<td>";
                            echo $result['name'];
                            echo "</td>";
                            echo "<td>";
                            echo $result['type'];
                            echo "</td>";
                            echo "<td>";
                            echo $result['sector'];
                            echo "</td>";
                            echo "<td>";
                            echo $result['address'];
                            echo "</td>";
                            echo "<td>";
                            echo $result['city'];
                            echo "</td>";
                            echo "<td>";
                            echo $result['province'];
                            echo "</td>";
                            echo "<td>";
                            echo $result['postalcode'];
                            echo "</td>";
                            echo "<td>";
                            echo $result['longitude'];
                            echo "</td>";
                            echo "<td>";
                            echo $result['latitude'];
                            echo "</td>";

                            echo "</tr>";
                        }
                    ?>
               
                 
        
            </tbody>
        </table>
    </div>
<?php
}
?>
 <?php
if($format=="json"){
    $decoded = json_encode($results);
    echo "$decoded";
}
?>

<?php
if($format=="xml"){
    
    $domDoc = new DOMDocument;
    $rootElt = $domDoc->createElement('root');
    $rootNode = $domDoc->appendChild($rootElt);
    
    $subElt = $domDoc->createElement('foo');
    $attr = $domDoc->createAttribute('ah');
    $attrVal = $domDoc->createTextNode('OK');
    $attr->appendChild($attrVal);
    $subElt->appendChild($attr);
    $subNode = $rootNode->appendChild($subElt);
    
    $textNode = $domDoc->createTextNode('Wow, it works!');
    $subNode->appendChild($textNode);
    
    echo "<pre>";
    echo htmlentities($domDoc->saveXML());
    echo "<pre>";

    // $xml = new SimpleXMLElement('<root/>');
    // array_walk_recursive($results, array ($xml, 'addChild'));
    // print $xml->asXML();
}
?>

<?php
if($format=="csv"){
    foreach($results as $result){
        echo $result['name'].",".$result['type'].",".$result['sector'].",".$result['address'].",".$result['city'].",".$result['province'].",".$result['postalcode'].",".$result['longitude'].",".$result['latitude']."<br>";
    }
}
?>

    
</div>
<script>
    // function encode(){
    //     var xhttp = new XMLHttpRequest();
    //     xhttp.onreadystatechange = function() {
    //         if (this.readyState == 4 && this.status == 200) {
    //             document.getElementById("converted").innerHTML = this.responseText;
    //         }
    //     };
    //     xhttp.open("GET", "encode.php", true);
    //     xhttp.send();
    // }
    // function decode(){
    //     var xhttp = new XMLHttpRequest();
    //     xhttp.onreadystatechange = function() {
    //         if (this.readyState == 4 && this.status == 200) {
    //             document.getElementById("converted").innerHTML = this.responseText;
    //         }
    //     };
    //     xhttp.open("GET", "decode.php", true);
    //     xhttp.send();
    // }
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

</body>
</html>
